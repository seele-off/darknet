const dotenv = require("dotenv");

dotenv.config();

const env = {}

module.exports = {
  publicRuntimeConfig: env,
};