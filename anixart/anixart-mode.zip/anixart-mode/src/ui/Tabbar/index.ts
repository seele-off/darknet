export { default } from './TabBar';
