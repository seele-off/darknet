export { default } from './TabBarItem';
