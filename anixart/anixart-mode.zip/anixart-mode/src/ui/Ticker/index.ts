export { default } from './Ticker';
