export type SvgProps = {
  width?: number;
  height?: number;
  fill?: string;
  className?: string;
};
