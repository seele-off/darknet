export { default } from './SeoHead';
