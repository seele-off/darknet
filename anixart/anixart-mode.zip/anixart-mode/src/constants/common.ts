/* eslint-disable import/prefer-default-export */
export const PHONE_IMAGE = '/images/phone.webp';
