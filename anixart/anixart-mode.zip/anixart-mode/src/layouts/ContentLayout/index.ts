export { default } from './ContentLayout';
